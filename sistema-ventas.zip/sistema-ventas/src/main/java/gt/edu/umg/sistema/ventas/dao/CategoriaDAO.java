package gt.edu.umg.sistema.ventas.dao;

import gt.edu.umg.sistema.ventas.modelo.Categoria;

public interface CategoriaDAO extends DAO<Categoria> {
}
