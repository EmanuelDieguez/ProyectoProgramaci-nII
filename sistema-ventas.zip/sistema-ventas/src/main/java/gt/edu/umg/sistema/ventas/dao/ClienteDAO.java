package gt.edu.umg.sistema.ventas.dao;

import gt.edu.umg.sistema.ventas.modelo.Cliente;

public interface ClienteDAO extends DAO<Cliente> {
}
