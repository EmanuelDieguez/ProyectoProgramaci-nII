package gt.edu.umg.sistema.ventas.dao;

import gt.edu.umg.sistema.ventas.modelo.Empleado;

public interface EmpleadoDAO extends DAO<Empleado> {
}
