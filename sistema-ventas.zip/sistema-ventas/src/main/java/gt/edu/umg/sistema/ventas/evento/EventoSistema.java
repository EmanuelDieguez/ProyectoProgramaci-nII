package gt.edu.umg.sistema.ventas.evento;

/** Qué parte del sistema cambió. Las ventanas abiertas se suscriben a lo que les interesa. */
public enum EventoSistema {
    CLIENTES, EMPLEADOS, CATEGORIAS, PRODUCTOS, BODEGAS, INVENTARIO, COMPRAS, FACTURAS, PAGOS
}
