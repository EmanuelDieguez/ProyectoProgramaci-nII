package gt.edu.umg.sistema.ventas.modelo;

public enum EstadoFactura {
    PENDIENTE, PAGADA, ANULADA
}
