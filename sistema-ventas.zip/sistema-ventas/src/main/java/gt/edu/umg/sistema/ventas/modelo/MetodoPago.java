package gt.edu.umg.sistema.ventas.modelo;

public enum MetodoPago {
    EFECTIVO, TARJETA, TRANSFERENCIA
}
