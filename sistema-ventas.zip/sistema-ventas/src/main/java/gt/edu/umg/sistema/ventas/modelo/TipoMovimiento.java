package gt.edu.umg.sistema.ventas.modelo;

public enum TipoMovimiento {
    ENTRADA, SALIDA
}
